## Example external plugin for bisweb

This directory contains an example plugin for bisweb. To use:

1. Place the contents of this file in a directory called external adjacent to
   the bisweb src directory

2. Get any dependencies (`d3` in this case)

    cd external
    npm update -d

3. Create a symbolic link to the the web/images directory next to your html
   files.
   
    cd external
    ln -sf ../src/web/images .

4. In bisweb/src  run `gulp serve` and `gulp build` using the `-x 1` to
   include files in here
   
### How it works

The main bisweb build (if `-x 1` or `--external 1` is specified) looks for a
file `../external/js/bisextra.js` (relative the main gulpfile.js) and appends
it to the webpack build. The best way to add new code is to make these into
web-components as in the example shown.

In addition running `gulp serve -x 1` changes to root of the development web
server to ``bisweb/src/..`` instead of the default `bisweb/src` to allow
access to html files under the external directory.

To try:

    cd bisweb/src
    gulp build -x 1
    gulp serve -x 1
    
Navigate to 
    
    http://localhost:8080/external/treeviewer.html
